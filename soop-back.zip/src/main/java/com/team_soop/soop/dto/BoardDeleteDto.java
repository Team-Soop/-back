package com.team_soop.soop.dto;

import lombok.Data;

@Data
public class BoardDeleteDto {
    private String menuCategoryName;
    private int boardId;
}
