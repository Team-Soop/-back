package com.team_soop.soop.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class SearchReportReqDto {
    private int menuCategoryId;
}
