package com.team_soop.soop.dto;

import lombok.Data;

@Data
public class SigninReqDto {
    private String username;
    private String password;
}
