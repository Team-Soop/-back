package com.team_soop.soop.entity;

import lombok.Data;

@Data
public class ClassLocation {
    private int classLocationId;
    private String classLocationName;
    private String classLocationColor;
    private String classLocationImgUrl;
}