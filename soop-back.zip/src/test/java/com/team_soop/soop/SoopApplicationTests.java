package com.team_soop.soop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoopApplicationTests {

	@Test
	void contextLoads() {
	}

}
